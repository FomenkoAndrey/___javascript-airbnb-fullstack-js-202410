class Person {
  constructor(
    public name: string,
    public age: number,
    public gender: string,
    public skills: string[]
  ) {}

  getSkills() {
    return this.skills
  }
}

const person = new Person('John', 20, 'male', ['html', 'css', 'javascript'])

console.log(person)
