type Person = {
  name: string
  age: number
  gender: string
  skills: string[]
  print?: () => void
}

type Developer = {
  level: string
  experience: number
}

const developer: Person & Developer = {
  name: 'John',
  age: 20,
  gender: 'male',
  skills: ['js', 'ts', 'react'],
  level: 'junior',
  experience: 1,
  print: () => {
    console.log('print')
  }
}

type SeniorDeveloper = Person & Developer

const teamlead: SeniorDeveloper = {
  name: 'John',
  age: 20,
  gender: 'male',
  skills: ['js', 'ts', 'react'],
  level: 'senior',
  experience: 10
}

const newHire: Partial<SeniorDeveloper> = {
  name: 'John',
  level: 'junior'
}
