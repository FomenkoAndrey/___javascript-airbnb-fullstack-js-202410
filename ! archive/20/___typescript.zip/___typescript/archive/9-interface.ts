interface LengthInterface {
  length: number
}

function getLength(data: LengthInterface) {
  return data.length
}

// type Person = {
//   name: string
//   age: number
//   gender: string
//   greet(msg: string): void
// }

// type GetName = {
//   skills: string[]
// }

interface PersonInterface {
  name: string
  age: number
  gender: string
  greet(msg: string): void
}

interface GetSkillsInterface {
  skills: string[]
}

const person: PersonInterface = {
  name: 'John',
  age: 20,
  gender: 'male',
  greet(msg: string) {
    console.log(msg)
  }
}

class Person implements PersonInterface, GetSkillsInterface {
  constructor(
    public name: string,
    public age: number,
    public gender: string,
    public skills: string[]
  ) {}

  greet(msg: string) {
    console.log(msg)
  }
}

// ------------------

interface ShapeInterface {
  name: string
  printArea(): void
}

class Circle implements ShapeInterface {
  name: string = 'Circle'

  constructor(public radius: number) {}

  printArea() {
    return Math.PI * this.radius * this.radius
  }
}

class Rectangle implements ShapeInterface {
  name: string = 'Rectangle'

  constructor(
    public width: number,
    public height: number
  ) {}

  printArea() {
    return this.width * this.height
  }
}

const circle = new Circle(10)
const rectangle = new Rectangle(10, 20)

console.log(circle.printArea())
console.log(rectangle.printArea())

const shapes: ShapeInterface[] = [circle, rectangle]

shapes.forEach((shape: ShapeInterface) => {
  console.log(shape.name)
  console.log(shape.printArea())
})
