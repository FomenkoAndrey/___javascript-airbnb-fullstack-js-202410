class Person {
  constructor(
    public name: string,
    private age: number,
    protected gender: string
  ) {}
}

const person = new Person('John', 20, 'male')

console.log(person)

class Developer extends Person {
  constructor(
    name: string,
    age: number,
    gender: string,
    public skills: string[]
  ) {
    super(name, age, gender)
  }

  getSkills() {
    return this.skills
  }
}

const developer = new Developer('John', 20, 'male', ['html', 'css', 'javascript'])

console.log(developer.getSkills())

abstract class Phone {
  public year: number = 2025

  public abstract price: number

  public abstract phoneMessage(msg: string): string

  constructor(public model: string) {}

  public getYear() {
    return this.year
  }
}

class Xiaomi extends Phone {
  price: number = 1000

  phoneMessage(msg: string): string {
    return `Xiaomi ${this.model} is ${msg}`
  }
}

class Samsung extends Phone {
  price: number = 2000

  phoneMessage(msg: string): string {
    return `Samsung ${this.model} is not ${msg}`
  }
}

const xiaomi = new Xiaomi('Redmi Note 11')
const samsung = new Samsung('Galaxy S22')

console.log(xiaomi.phoneMessage('good'))
console.log(samsung.phoneMessage('bad'))
