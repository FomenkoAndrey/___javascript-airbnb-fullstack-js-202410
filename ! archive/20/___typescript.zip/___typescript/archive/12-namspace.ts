const isEmpty = 123
const isUndefined = 345
const PI = 3.14
const EXP = 2.718

namespace Utils {
  export const isEmpty = (data: any) => !data
  export const isUndefined = (data: any) => typeof data === 'undefined'
  export const PI = 3.14
  export const EXP = 2.718
}

console.log(Utils.isEmpty(123))
console.log(Utils.isUndefined(123))
console.log(Utils.PI)
console.log(Utils.EXP)

namespace Outer {
  export namespace Inner {
    export const PI = 3.14
  }
}

console.log(Outer.Inner.PI)

import Inner = Outer.Inner

console.log(Inner.PI)

namespace Validation {
  export interface StringValidator {
    isValid(str: string): boolean
  }
}

namespace Validation {
  export class EmailValidator implements StringValidator {
    isValid(str: string): boolean {
      return str.includes('@')
    }
  }
}

const emailValidator = new Validation.EmailValidator()
console.log(emailValidator.isValid('test@test.com'))
