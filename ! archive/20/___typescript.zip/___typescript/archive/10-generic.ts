function getData<T>(data: T): T {
  return data
}

console.log(getData('Hello').length)
console.log(getData(123).toFixed())

const fn: <T>(d: T) => T = getData

class Multiply<T extends number | string> {
  constructor(
    private num1: T,
    private num2: T
  ) {}

  multiply() {
    return +this.num1 * +this.num2
  }
}

const mulNum = new Multiply(10, 20)
console.log(mulNum.multiply())

const mulStr = new Multiply<string>('10', '20')
console.log(mulStr.multiply())
