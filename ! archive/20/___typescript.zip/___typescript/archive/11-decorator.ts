function consoleLog(constructorFn: Function) {
  console.log(constructorFn)
}

function conditionLog(condition: boolean) {
  return condition ? consoleLog : () => {}
}

// @consoleLog
// @conditionLog(false)

function AddPrinter(constructorFn: Function) {
  console.dir(constructorFn)

  constructorFn.prototype.addPrinter = function () {
    const p = document.createElement('p')

    p.innerHTML = `
      <div>
        <h3>Name: ${this.name}</h3>
        <p>Age: ${this.age}</p>
        <p>Email: ${this.email}</p>
        <p>Is Admin: ${this.isAdmin}</p>
        <p>Skills: ${this.skills.join(', ')}</p>
      </div>
    `

    document.body.append(p)
  }
}

@AddPrinter
class Person {
  constructor(
    public name: string,
    public age: number,
    public email: string,
    public isAdmin: boolean,
    public skills: string[]
  ) {
    console.log('Hello from Person constructor')
  }
}

const person: any = new Person('John', 20, 'john@gmail.com', true, ['React', 'Node'])
person.addPrinter()

// --------------
console.log('--------------')
// --------------

function ReadOnly(target: any, key: string) {
  console.dir(target)
  console.dir(key)
  Object.defineProperty(target, key, {
    get: () => 'Default name',
    set: (_) => {}
  })
}

function OverrideName(label: string) {
  return function (target: any, key: string) {
    Object.defineProperty(target, key, {
      get: () => label,
      set: (_) => {}
    })
  }
}

class Test {
  // @ReadOnly
  @OverrideName('Text for override')
  name: string = 'Hello world'
}

const test = new Test()

console.log(test.name)

test.name = 'New Hello'

console.log(test.name)
