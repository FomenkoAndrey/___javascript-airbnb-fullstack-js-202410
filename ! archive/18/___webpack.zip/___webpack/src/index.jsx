import '@css/style.css'
import '@less/style.less'
import '@sass/style.sass'
import '@sass/style.scss'

import React from 'react'
import ReactDOM from 'react-dom/client'

import Post from '@model/post'
import jsonData from '@assets/data'
import logo from '@assets/icon-square-big.png'

import '@model/lodash'

const post = new Post('Webpack Post Title', logo)

// import $ from 'jquery'
// $('pre').addClass('code').text(post.toString())

console.log('Data:', jsonData)

async function start() {
  return await new Promise((r) => setTimeout(() => r('Async done.'), 2000))
}

start().then((res) => console.log(res))

const App = () => (
  <div className="container">
    <h1>Webpack training</h1>
    <div className="logo" />
    <pre />
    <div className="less-demo">
      <h2>Less demo</h2>
    </div>
    <div className="sass-demo">
      <h2>Sass demo</h2>
    </div>
    <div className="scss-demo">
      <h2>SCSS demo</h2>
    </div>
  </div>
)

const root = ReactDOM.createRoot(document.getElementById('root'))
root.render(<App />)
