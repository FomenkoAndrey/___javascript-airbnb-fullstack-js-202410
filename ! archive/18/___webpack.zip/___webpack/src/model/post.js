export default class Post {
  constructor(title, image) {
    this.title = title;
    this.image = image;
    this.date = new Date();
  }

  toString() {
    return JSON.stringify(
      {
        date: this.date.toJSON(),
        image: this.image,
        title: this.title
      },
      null,
      2
    );
  }
}
