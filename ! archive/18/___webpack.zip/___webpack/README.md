# Pre Webpack Files

Потрібно створити файл: webpack.config.js