# Для локального використання TypeScript потрібно:

npm init -y
npm i -D typescript
npx tsc --init

# Оскільки пакет встановлений локально, то команди для запуску будуть через npx:

npx tsc -v
npx tsc
npx tsc -w
