const arr = [
  'html',
  'css',
  'javascript',
  'typescript',
  'react',
  'nodejs',
  'nextjs',
  'tailwindcss',
  'mongodb',
  'express',
  'docker'
]

// console.log(arr[0])
// console.log(arr[2])
// console.log(arr[5])

enum Skills {
  HTML,
  CSS,
  JAVASCRIPT,
  TYPESCRIPT,
  REACT,
  NODEJS,
  NEXTJS,
  TAILWIND,
  MONGODB,
  EXPRESS,
  DOCKER
}

console.log(arr[Skills.HTML])
console.log(arr[Skills.CSS])
console.log(arr[Skills.JAVASCRIPT])
console.log(arr[Skills.TYPESCRIPT])
console.log(arr[Skills.REACT])
console.log(arr[Skills.NODEJS])

function error(message: string): never {
  throw new Error(message)
}

function fail(): never {
  return error('Something failed')
}

function loop(): never {
  while (true) {
    console.log('Looping...')
  }
}

function print(message: string): void {
  console.log(message)
}

print('Hello, world!')

let num: number | null | undefined

num = 123
num = null
num = undefined
num = NaN

function getValue(): unknown {
  return 'Hello, world!' // 123, true
}

const result: unknown = getValue()

if (typeof result === 'string') {
  console.log(result.toUpperCase())
} else if (typeof result === 'number') {
  console.log(result.toFixed(2))
} else {
  console.log('Unknown value')
}
