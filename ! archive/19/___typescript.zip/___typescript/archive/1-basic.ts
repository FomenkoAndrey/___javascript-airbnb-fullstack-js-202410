let strJs = 'Hello World'
let strTs: string = 'Hello World'

let numJs = 123
let numTs: number = 123

let boolJs = true
let boolTs: boolean = true

let anyType: any
anyType = 'Hello World'
anyType = 123
anyType = true

let strNumType: string | number
strNumType = 'Hello World'
strNumType = 123

let strNumBoolType: string | number | boolean
strNumBoolType = 'Hello World'
strNumBoolType = 123
strNumBoolType = true
