// function getName(name: string): string {
//   return name
// }

// function getAge(age: number): number {
//   return age
// }

function getNameAge(name: string = 'John Doe', age: number = 20): string {
  return `${name} is ${age} years old`
}

getNameAge('John Doe', 20)
getNameAge('John Doe')
getNameAge()

function log(message: string): void {
  console.log(message)
}

function sum(a: number, b: number): number {
  return a + b
}

const sum1 = (a: number, b: number): number => a + b

const sum2 = (a: number | string, b: number | string): number => +a + +b

const sum3: (a: number, b: number) => number = sum1
const sum4: (a: number | string, b: number | string) => number = sum2
