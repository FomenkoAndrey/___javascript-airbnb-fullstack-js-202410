// ! Intersection Types
type Employee = {
  name: string
  startDate: Date
}

type Workman = {
  hasBadge: boolean
}

type EmployeeWithBadge = Employee & Workman

const employeeWithBadge: EmployeeWithBadge = {
  name: 'John',
  startDate: new Date(),
  hasBadge: true
}

// ! Partial Types
type PartialEmployee = Partial<Employee>

const partialEmployee: PartialEmployee = {
  name: 'John'
}

// ! Readonly Types
type ReadonlyEmployee = Readonly<Employee>

const readonlyEmployee: ReadonlyEmployee = {
  name: 'John',
  startDate: new Date()
}

// readonlyEmployee.name = 'Jane' // ! Error

// ! Required Types
type RequiredEmployee = Required<PartialEmployee>

const requiredEmployee: RequiredEmployee = {
  name: 'John',
  startDate: new Date()
}

// ! Pick Types
// type PickEmployee = Pick<Employee, 'name'>
// const pickEmployee: PickEmployee = {
//   name: 'John'
// }
type PickEmployee = Pick<EmployeeWithBadge, 'name' | 'hasBadge'>

const pickEmployee: PickEmployee = {
  name: 'John',
  hasBadge: true
}

// ! Return Type
function getEmployee(name: string, startDate: Date): Employee {
  return {
    name,
    startDate
  }
}

type GetEmployeeReturnType = ReturnType<typeof getEmployee>

const employee: GetEmployeeReturnType = getEmployee('John', new Date())
