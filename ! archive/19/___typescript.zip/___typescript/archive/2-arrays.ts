const strArrJs = ['Hello', 'World']
const strArrTs: string[] = ['Hello', 'World']
const strArrJs2: Array<string> = ['Hello', 'World']

const numArrJs = [1, 2, 3]
const numArrTs: number[] = [1, 2, 3]
const numArrJs2: Array<number> = [1, 2, 3]

const boolArrJs = [true, false]
const boolArrTs: boolean[] = [true, false]
const boolArrJs2: Array<boolean> = [true, false]

const someTypesArrJs = ['Hello', 1, true]
const someTypesArrTs: (string | number | boolean)[] = ['Hello', 1, true, 'World', 123]
const someTypesArrJs2: Array<string | number | boolean> = ['Hello', 1, true, 'World', 123]

const tupleTs: [number, number, number, string] = [1, 2, 3, 'total']
const tupleTs2: [number, string] = [1, 'total']

const anyArr: any[] = ['Hello', 1, true, 1, {}, [], () => {}, null, undefined]
